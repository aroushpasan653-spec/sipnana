NEXTGEN LEARN - ආරම්භක උපදෙස්

මෙම ZIP එකේ Website එකේ සියලුම මුල් files වෙන වෙනම ඇත.

Folder structure:
nextgen-learn/
  index.html
  grades.html
  ol.html
  al.html
  study.html
  quiz.html
  about.html
  contact.html
  css/style.css
  js/translations.js
  js/main.js
  js/quiz.js

GitHub වෙත දමන ආකාරය:
1. ZIP එක Android phone එකට download කර Extract කරන්න.
2. GitHub හි nextgen-learn repository එක විවෘත කරන්න.
3. Add file > Upload files තෝරන්න.
4. Extract කළ folder එක ඇතුළත ඇති සියලුම files සහ css, js folders ඒවායේ folder structure එක රැකගෙන upload කරන්න.
5. Commit changes කරන්න.

වැදගත්:
- පැරණි index.html එක අලුත් index.html එකෙන් replace කරන්න.
- css සහ js folders ඇතුළත files නිවැරදිව upload කළ යුතුයි.
- GitHub Pages සක්‍රිය කිරීමට Settings > Pages > Deploy from a branch > main > /(root) > Save යන්න.
- Website එක publish වීමට මිනිත්තු කිහිපයක් ගත විය හැක.
- දැනට මෙය front-end starter website එකකි. සැබෑ පාඩම්, PDF files, student accounts, database හෝ admin dashboard තවම සකසා නැත.
- Google Fonts සඳහා internet connection අවශ්‍ය විය හැක. Fonts නොලැබුණත් website එක සාමාන්‍ය fonts භාවිතයෙන් ක්‍රියා කරයි.
- සියලුම අධ්‍යාපන සම්පත් ඔබම සකස් කළ හෝ අවසර ලබාගත් ඒවා විය යුතුය.
