document.addEventListener("DOMContentLoaded", () => {
  const translations = window.NEXTGEN_TRANSLATIONS || {};
  const languageSelect = document.getElementById("languageSelect");

  function applyLanguage(lang) {
    const dict = translations[lang] || translations.en;
    document.documentElement.lang = lang;
    document.querySelectorAll("[data-i18n]").forEach((el) => {
      const key = el.getAttribute("data-i18n");
      if (dict[key] !== undefined) el.innerHTML = dict[key];
    });
    if (languageSelect) languageSelect.value = lang;
    try { localStorage.setItem("nextgen-language", lang); } catch (e) {}
  }

  let savedLanguage = "si";
  try { savedLanguage = localStorage.getItem("nextgen-language") || "si"; } catch (e) {}
  applyLanguage(savedLanguage);
  if (languageSelect) languageSelect.addEventListener("change", (e) => applyLanguage(e.target.value));

  const themeButton = document.querySelector(".theme-toggle");
  let savedTheme = "dark";
  try { savedTheme = localStorage.getItem("nextgen-theme") || "dark"; } catch (e) {}
  if (savedTheme === "light") document.body.classList.add("light");
  if (themeButton) {
    themeButton.textContent = document.body.classList.contains("light") ? "☾" : "☼";
    themeButton.addEventListener("click", () => {
      document.body.classList.toggle("light");
      const theme = document.body.classList.contains("light") ? "light" : "dark";
      themeButton.textContent = theme === "light" ? "☾" : "☼";
      try { localStorage.setItem("nextgen-theme", theme); } catch (e) {}
    });
  }

  const menuButton = document.querySelector(".menu-toggle");
  const nav = document.querySelector(".main-nav");
  if (menuButton && nav) menuButton.addEventListener("click", () => {
    const open = nav.classList.toggle("open");
    menuButton.setAttribute("aria-expanded", String(open));
    menuButton.textContent = open ? "×" : "☰";
  });

  const year = document.getElementById("year");
  if (year) year.textContent = new Date().getFullYear();

  const revealItems = document.querySelectorAll(".reveal");
  if ("IntersectionObserver" in window) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible");
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    revealItems.forEach((item) => observer.observe(item));
  } else revealItems.forEach((item) => item.classList.add("visible"));

  const gradeGrid = document.getElementById("gradeGrid");
  if (gradeGrid) {
    for (let grade = 1; grade <= 9; grade++) {
      const tile = document.createElement("a");
      tile.className = "grade-tile reveal visible";
      tile.href = "study.html";
      const label = document.createElement("b");
      label.textContent = `Grade ${grade}`;
      const detail = document.createElement("span");
      detail.textContent = "Study resources ↗";
      tile.append(label, detail);
      gradeGrid.appendChild(tile);
    }
  }
});