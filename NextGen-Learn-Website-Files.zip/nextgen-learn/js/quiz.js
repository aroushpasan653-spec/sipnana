document.addEventListener("DOMContentLoaded", () => {
  const options = document.querySelectorAll(".quiz-option");
  const feedback = document.getElementById("quizFeedback");
  const reset = document.getElementById("quizReset");
  const messages = () => {
    const lang = document.getElementById("languageSelect")?.value || "en";
    const dict = window.NEXTGEN_TRANSLATIONS?.[lang] || window.NEXTGEN_TRANSLATIONS?.en || {};
    return { correct: dict.correctFeedback || "Correct!", wrong: dict.wrongFeedback || "Try again." };
  };
  options.forEach((button) => button.addEventListener("click", () => {
    options.forEach((item) => item.classList.remove("correct", "wrong"));
    const msg = messages();
    if (button.dataset.answer === "correct") {
      button.classList.add("correct");
      if (feedback) feedback.textContent = msg.correct;
    } else {
      button.classList.add("wrong");
      if (feedback) feedback.textContent = msg.wrong;
    }
  }));
  if (reset) reset.addEventListener("click", () => {
    options.forEach((item) => item.classList.remove("correct", "wrong"));
    if (feedback) feedback.textContent = "";
  });
});